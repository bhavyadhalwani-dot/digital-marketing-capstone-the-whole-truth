# Welcome Email
Welcome to The Whole Truth family! Get 10% off on your first order.