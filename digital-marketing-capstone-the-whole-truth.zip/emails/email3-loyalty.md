# Loyalty Program Email
Thank you for being a loyal customer! Earn rewards with every purchase.