# Digital Marketing Capstone Project – The Whole Truth

## Objective
Design a 3-month multi-channel digital strategy to drive D2C revenue, build trust, and increase subscribers.

## Project Structure
- Report (Markdown/PDF)
- Blogs
- Email Campaigns
- Social Media Posts
- Mockup Prompts

## Predicted Outcomes
- 30–40% increase in website traffic
- 15–20% boost in D2C revenue
- 3x ROAS from paid ads

