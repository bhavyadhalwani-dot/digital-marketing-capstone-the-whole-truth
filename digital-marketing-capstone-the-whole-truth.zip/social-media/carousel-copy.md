# Instagram Carousel Copy
Slide 1: What’s inside your snack?
Slide 2: Hidden sugars vs. The Whole Truth
Slide 3: Choose honesty, choose health.