# Instagram Captions
1. Fuel your day with honesty. 💪 #CleanEating
2. No secrets, just real food. 🌱 #TheWholeTruth